
// // // // lib/screens/auth_gate.dart
// // // //
// // // // Root navigator for the app.
// // // //
// // // // Routing logic:
// // // //   Firebase null                 → LoginPage
// // // //   Firebase anonymous            → App (guest — browse only, no profile needed)
// // // //   Firebase real, no profile yet → ProfileSetupScreen  (first-time user)
// // // //   Firebase real, profile exists → App
// // // //
// // // // IMPORTANT — AuthGate must never unmount PersistentBottomNavBar due to a
// // // // transient loading state. Doing so corrupts each tab's NavigatorState and
// // // // triggers '_history.isNotEmpty' assertion crashes.
// // // //
// // // // The guard: once we know the user is signed in (anonymous or real), we
// // // // only show _SplashScreen while waiting for the *initial* profile load.
// // // // After that, we keep showing the app even if currentUserProvider briefly
// // // // goes to AsyncLoading (e.g. on token refresh or tab change).

// // // import 'package:flutter/material.dart';
// // // import 'package:flutter_riverpod/flutter_riverpod.dart';

// // // import '../providers/auth_provider.dart';
// // // import '../providers/user_provider.dart';
// // // import '../screens/login_page.dart';
// // // import '../screens/profile_setup_screen.dart';
// // // import '../widgets/nav_bar.dart';

// // // class AuthGate extends ConsumerWidget {
// // //   const AuthGate({super.key});

// // //   @override
// // //   Widget build(BuildContext context, WidgetRef ref) {
// // //     // Watch Firebase auth state — this is stable after cold start.
// // //     final authState = ref.watch(authStateProvider);

// // //     return authState.when(
// // //       // ── Cold start — Firebase restoring session ────────────────────────
// // //       loading: () => const _SplashScreen(),

// // //       error: (err, _) => Scaffold(
// // //         body: Center(child: Text('Auth error: $err')),
// // //       ),

// // //       data: (fbUser) {
// // //         // ── Not signed in ──────────────────────────────────────────────
// // //         if (fbUser == null) return const LoginPage();

// // //         // ── Anonymous guest ────────────────────────────────────────────
// // //         // No profile required; skip currentUserProvider entirely.
// // //         // This avoids the Firestore stream that would fire for anonymous
// // //         // UIDs and cause PERMISSION_DENIED + navigator crash.
// // //         if (fbUser.isAnonymous) {
// // //           return PersistentBottomNavBar(uid: fbUser.uid);
// // //         }

// // //         // ── Real authenticated user ────────────────────────────────────
// // //         // Use select() so we only rebuild on meaningful transitions
// // //         // (null → value, or value → null), NOT on every AsyncLoading tick.
// // //         final hasProfile = ref.watch(
// // //           currentUserProvider.select((async) {
// // //             // While loading, keep whatever was there before (skipLoadingOnRefresh).
// // //             // AsyncLoading before first data → null (show splash).
// // //             // AsyncLoading after first data → treat as "still has profile".
// // //             if (async is AsyncLoading && async.hasValue) {
// // //               return async.value != null;
// // //             }
// // //             // AsyncData or AsyncError
// // //             return async.asData?.value != null;
// // //           }),
// // //         );

// // //         // Only show splash if we've never loaded anything yet.
// // //         final isFirstLoad = ref.watch(
// // //           currentUserProvider.select(
// // //             (async) => async is AsyncLoading && !async.hasValue,
// // //           ),
// // //         );

// // //         if (isFirstLoad) return const _SplashScreen();

// // //         return hasProfile
// // //             ? PersistentBottomNavBar(uid: fbUser.uid)
// // //             : const ProfileSetupScreen();
// // //       },
// // //     );
// // //   }
// // // }

// // // // ─────────────────────────────────────────────────────────────────────────────
// // // // Splash — shown only during cold-start auth resolution
// // // // ─────────────────────────────────────────────────────────────────────────────

// // // class _SplashScreen extends StatelessWidget {
// // //   const _SplashScreen();

// // //   @override
// // //   Widget build(BuildContext context) {
// // //     final isDark =
// // //         Theme.of(context).brightness == Brightness.dark;
// // //     return Scaffold(
// // //       backgroundColor: isDark
// // //           ? const Color(0xFF0D0D0D)
// // //           : const Color(0xFFF8F9FA),
// // //       body: const Center(
// // //         child: SizedBox(
// // //           width: 28,
// // //           height: 28,
// // //           child: CircularProgressIndicator(
// // //             color: Color(0xFFE91E8C),
// // //             strokeWidth: 2.5,
// // //           ),
// // //         ),
// // //       ),
// // //     );
// // //   }
// // // }
// // // lib/screens/auth_gate.dart
// // //
// // // Root navigator for the app.
// // //
// // // Routing logic:
// // //   Firebase null                          → LoginPage
// // //   Firebase user (anon OR real), loading  → SplashScreen (first load only)
// // //   Firebase user, no profile in cache     → ProfileSetupScreen
// // //   Firebase user, profile loaded          → App (PersistentBottomNavBar)
// // //
// // // Anonymous users are now FULL users — they go through ProfileSetup once,
// // // get a profile cached locally, and their Firebase session is preserved
// // // across logout/login cycles (signOutSmart skips Firebase signOut for them).
// // //
// // // AuthGate must never unmount PersistentBottomNavBar on a transient
// // // AsyncLoading tick — doing so corrupts each tab's NavigatorState and
// // // triggers '_history.isNotEmpty' crashes on swipe-back devices.

// // import 'package:flutter/material.dart';
// // import 'package:flutter_riverpod/flutter_riverpod.dart';

// // import '../providers/auth_provider.dart';
// // import '../providers/user_provider.dart';
// // import '../screens/login_page.dart';
// // import '../screens/profile_setup_screen.dart';
// // import '../widgets/nav_bar.dart';

// // class AuthGate extends ConsumerWidget {
// //   const AuthGate({super.key});

// //   @override
// //   Widget build(BuildContext context, WidgetRef ref) {
// //     // Watch Firebase auth state — this is stable after cold start.
// //     final authState = ref.watch(authStateProvider);

// //     return authState.when(
// //       // ── Cold start — Firebase restoring session ────────────────────────
// //       loading: () => const _SplashScreen(),

// //       error: (err, _) => Scaffold(
// //         body: Center(child: Text('Auth error: $err')),
// //       ),

// //       data: (fbUser) {
// //         // ── Not signed in ──────────────────────────────────────────────
// //         if (fbUser == null) return const LoginPage();

// //         // ── Any authenticated user (anonymous OR real) ─────────────────
// //         // Anonymous users have full profiles stored in cache (created via
// //         // ProfileSetupScreen on first launch). Their Firebase session is
// //         // preserved across logout cycles so they return here seamlessly.
// //         //
// //         // Both anonymous and real users go through the same profile-load
// //         // path: currentUserProvider → cache → ProfileSetup if missing.
// //         final hasProfile = ref.watch(
// //           currentUserProvider.select((async) {
// //             // While loading, keep whatever was there before (skipLoadingOnRefresh).
// //             // AsyncLoading before first data → null (show splash).
// //             // AsyncLoading after first data → treat as "still has profile".
// //             if (async is AsyncLoading && async.hasValue) {
// //               return async.value != null;
// //             }
// //             // AsyncData or AsyncError
// //             return async.asData?.value != null;
// //           }),
// //         );

// //         // Only show splash if we've never loaded anything yet.
// //         final isFirstLoad = ref.watch(
// //           currentUserProvider.select(
// //             (async) => async is AsyncLoading && !async.hasValue,
// //           ),
// //         );

// //         if (isFirstLoad) return const _SplashScreen();

// //         return hasProfile
// //             ? PersistentBottomNavBar(uid: fbUser.uid)
// //             : const ProfileSetupScreen();
// //       },
// //     );
// //   }
// // }

// // // ─────────────────────────────────────────────────────────────────────────────
// // // Splash — shown only during cold-start auth resolution
// // // ─────────────────────────────────────────────────────────────────────────────

// // class _SplashScreen extends StatelessWidget {
// //   const _SplashScreen();

// //   @override
// //   Widget build(BuildContext context) {
// //     final isDark =
// //         Theme.of(context).brightness == Brightness.dark;
// //     return Scaffold(
// //       backgroundColor: isDark
// //           ? const Color(0xFF0D0D0D)
// //           : const Color(0xFFF8F9FA),
// //       body: const Center(
// //         child: SizedBox(
// //           width: 28,
// //           height: 28,
// //           child: CircularProgressIndicator(
// //             color: Color(0xFFE91E8C),
// //             strokeWidth: 2.5,
// //           ),
// //         ),
// //       ),
// //     );
// //   }
// // }
// // lib/screens/auth_gate.dart
// //
// // Root navigator for the app.
// //
// // Routing logic:
// //   Firebase null                → LoginPage
// //   Firebase user, first load   → SplashScreen
// //   Firebase user, no profile   → ProfileSetupScreen  (first-time user)
// //   Firebase user, has profile  → App (PersistentBottomNavBar)
// //
// // AuthGate must NEVER unmount PersistentBottomNavBar on a transient
// // AsyncLoading tick — doing so corrupts each tab's NavigatorState and
// // triggers '_history.isNotEmpty' crashes on swipe-back devices (Realme, OnePlus).

// import 'package:flutter/material.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';

// import '../providers/auth_provider.dart';
// import '../providers/user_provider.dart';
// import '../screens/login_page.dart';
// import '../screens/profile_setup_screen.dart';
// import '../widgets/nav_bar.dart';

// class AuthGate extends ConsumerWidget {
//   const AuthGate({super.key});

//   @override
//   Widget build(BuildContext context, WidgetRef ref) {
//     final authState = ref.watch(authStateProvider);

//     return authState.when(
//       // ── Cold start — Firebase restoring session ────────────────────────
//       loading: () => const _SplashScreen(),

//       error: (err, _) => Scaffold(
//         body: Center(child: Text('Auth error: $err')),
//       ),

//       data: (fbUser) {
//         // ── Not signed in ──────────────────────────────────────────────
//         if (fbUser == null) return const LoginPage();

//         // ── Signed-in user ─────────────────────────────────────────────
//         // Use select() — rebuild only on null↔value transitions, NOT on
//         // every AsyncLoading tick (avoids unmounting PersistentBottomNavBar).
//         final hasProfile = ref.watch(
//           currentUserProvider.select((async) {
//             // While loading after first data, treat as "still has profile".
//             if (async is AsyncLoading && async.hasValue) {
//               return async.value != null;
//             }
//             return async.asData?.value != null;
//           }),
//         );

//         // Only show splash on the very first load (before any data).
//         final isFirstLoad = ref.watch(
//           currentUserProvider.select(
//             (async) => async is AsyncLoading && !async.hasValue,
//           ),
//         );

//         if (isFirstLoad) return const _SplashScreen();

//         return hasProfile
//             ? PersistentBottomNavBar(uid: fbUser.uid)
//             : const ProfileSetupScreen();
//       },
//     );
//   }
// }

// // ─────────────────────────────────────────────────────────────────────────────
// // Splash — shown only during cold-start auth resolution
// // ─────────────────────────────────────────────────────────────────────────────

// class _SplashScreen extends StatelessWidget {
//   const _SplashScreen();

//   @override
//   Widget build(BuildContext context) {
//     final isDark =
//         Theme.of(context).brightness == Brightness.dark;
//     return Scaffold(
//       backgroundColor: isDark
//           ? const Color(0xFF0D0D0D)
//           : const Color(0xFFF8F9FA),
//       body: const Center(
//         child: SizedBox(
//           width: 28,
//           height: 28,
//           child: CircularProgressIndicator(
//             color: Color(0xFFE91E8C),
//             strokeWidth: 2.5,
//           ),
//         ),
//       ),
//     );
//   }
// }
// // // lib/screens/auth_gate.dart
// // //
// // // Root navigator for the app.
// // //
// // // Routing logic:
// // //   Firebase null                 → LoginPage
// // //   Firebase anonymous            → App (guest — browse only, no profile needed)
// // //   Firebase real, no profile yet → ProfileSetupScreen  (first-time user)
// // //   Firebase real, profile exists → App
// // //
// // // IMPORTANT — AuthGate must never unmount PersistentBottomNavBar due to a
// // // transient loading state. Doing so corrupts each tab's NavigatorState and
// // // triggers '_history.isNotEmpty' assertion crashes.
// // //
// // // The guard: once we know the user is signed in (anonymous or real), we
// // // only show _SplashScreen while waiting for the *initial* profile load.
// // // After that, we keep showing the app even if currentUserProvider briefly
// // // goes to AsyncLoading (e.g. on token refresh or tab change).

// // import 'package:flutter/material.dart';
// // import 'package:flutter_riverpod/flutter_riverpod.dart';

// // import '../providers/auth_provider.dart';
// // import '../providers/user_provider.dart';
// // import '../screens/login_page.dart';
// // import '../screens/profile_setup_screen.dart';
// // import '../widgets/nav_bar.dart';

// // class AuthGate extends ConsumerWidget {
// //   const AuthGate({super.key});

// //   @override
// //   Widget build(BuildContext context, WidgetRef ref) {
// //     // Watch Firebase auth state — this is stable after cold start.
// //     final authState = ref.watch(authStateProvider);

// //     return authState.when(
// //       // ── Cold start — Firebase restoring session ────────────────────────
// //       loading: () => const _SplashScreen(),

// //       error: (err, _) => Scaffold(
// //         body: Center(child: Text('Auth error: $err')),
// //       ),

// //       data: (fbUser) {
// //         // ── Not signed in ──────────────────────────────────────────────
// //         if (fbUser == null) return const LoginPage();

// //         // ── Anonymous guest ────────────────────────────────────────────
// //         // No profile required; skip currentUserProvider entirely.
// //         // This avoids the Firestore stream that would fire for anonymous
// //         // UIDs and cause PERMISSION_DENIED + navigator crash.
// //         if (fbUser.isAnonymous) {
// //           return PersistentBottomNavBar(uid: fbUser.uid);
// //         }

// //         // ── Real authenticated user ────────────────────────────────────
// //         // Use select() so we only rebuild on meaningful transitions
// //         // (null → value, or value → null), NOT on every AsyncLoading tick.
// //         final hasProfile = ref.watch(
// //           currentUserProvider.select((async) {
// //             // While loading, keep whatever was there before (skipLoadingOnRefresh).
// //             // AsyncLoading before first data → null (show splash).
// //             // AsyncLoading after first data → treat as "still has profile".
// //             if (async is AsyncLoading && async.hasValue) {
// //               return async.value != null;
// //             }
// //             // AsyncData or AsyncError
// //             return async.asData?.value != null;
// //           }),
// //         );

// //         // Only show splash if we've never loaded anything yet.
// //         final isFirstLoad = ref.watch(
// //           currentUserProvider.select(
// //             (async) => async is AsyncLoading && !async.hasValue,
// //           ),
// //         );

// //         if (isFirstLoad) return const _SplashScreen();

// //         return hasProfile
// //             ? PersistentBottomNavBar(uid: fbUser.uid)
// //             : const ProfileSetupScreen();
// //       },
// //     );
// //   }
// // }

// // // ─────────────────────────────────────────────────────────────────────────────
// // // Splash — shown only during cold-start auth resolution
// // // ─────────────────────────────────────────────────────────────────────────────

// // class _SplashScreen extends StatelessWidget {
// //   const _SplashScreen();

// //   @override
// //   Widget build(BuildContext context) {
// //     final isDark =
// //         Theme.of(context).brightness == Brightness.dark;
// //     return Scaffold(
// //       backgroundColor: isDark
// //           ? const Color(0xFF0D0D0D)
// //           : const Color(0xFFF8F9FA),
// //       body: const Center(
// //         child: SizedBox(
// //           width: 28,
// //           height: 28,
// //           child: CircularProgressIndicator(
// //             color: Color(0xFFE91E8C),
// //             strokeWidth: 2.5,
// //           ),
// //         ),
// //       ),
// //     );
// //   }
// // }
// // lib/screens/auth_gate.dart
// //
// // Root navigator for the app.
// //
// // Routing logic:
// //   Firebase null                          → LoginPage
// //   Firebase user (anon OR real), loading  → SplashScreen (first load only)
// //   Firebase user, no profile in cache     → ProfileSetupScreen
// //   Firebase user, profile loaded          → App (PersistentBottomNavBar)
// //
// // Anonymous users are now FULL users — they go through ProfileSetup once,
// // get a profile cached locally, and their Firebase session is preserved
// // across logout/login cycles (signOutSmart skips Firebase signOut for them).
// //
// // AuthGate must never unmount PersistentBottomNavBar on a transient
// // AsyncLoading tick — doing so corrupts each tab's NavigatorState and
// // triggers '_history.isNotEmpty' crashes on swipe-back devices.

// import 'package:flutter/material.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';

// import '../providers/auth_provider.dart';
// import '../providers/user_provider.dart';
// import '../screens/login_page.dart';
// import '../screens/profile_setup_screen.dart';
// import '../widgets/nav_bar.dart';

// class AuthGate extends ConsumerWidget {
//   const AuthGate({super.key});

//   @override
//   Widget build(BuildContext context, WidgetRef ref) {
//     // Watch Firebase auth state — this is stable after cold start.
//     final authState = ref.watch(authStateProvider);

//     return authState.when(
//       // ── Cold start — Firebase restoring session ────────────────────────
//       loading: () => const _SplashScreen(),

//       error: (err, _) => Scaffold(
//         body: Center(child: Text('Auth error: $err')),
//       ),

//       data: (fbUser) {
//         // ── Not signed in ──────────────────────────────────────────────
//         if (fbUser == null) return const LoginPage();

//         // ── Any authenticated user (anonymous OR real) ─────────────────
//         // Anonymous users have full profiles stored in cache (created via
//         // ProfileSetupScreen on first launch). Their Firebase session is
//         // preserved across logout cycles so they return here seamlessly.
//         //
//         // Both anonymous and real users go through the same profile-load
//         // path: currentUserProvider → cache → ProfileSetup if missing.
//         final hasProfile = ref.watch(
//           currentUserProvider.select((async) {
//             // While loading, keep whatever was there before (skipLoadingOnRefresh).
//             // AsyncLoading before first data → null (show splash).
//             // AsyncLoading after first data → treat as "still has profile".
//             if (async is AsyncLoading && async.hasValue) {
//               return async.value != null;
//             }
//             // AsyncData or AsyncError
//             return async.asData?.value != null;
//           }),
//         );

//         // Only show splash if we've never loaded anything yet.
//         final isFirstLoad = ref.watch(
//           currentUserProvider.select(
//             (async) => async is AsyncLoading && !async.hasValue,
//           ),
//         );

//         if (isFirstLoad) return const _SplashScreen();

//         return hasProfile
//             ? PersistentBottomNavBar(uid: fbUser.uid)
//             : const ProfileSetupScreen();
//       },
//     );
//   }
// }

// // ─────────────────────────────────────────────────────────────────────────────
// // Splash — shown only during cold-start auth resolution
// // ─────────────────────────────────────────────────────────────────────────────

// class _SplashScreen extends StatelessWidget {
//   const _SplashScreen();

//   @override
//   Widget build(BuildContext context) {
//     final isDark =
//         Theme.of(context).brightness == Brightness.dark;
//     return Scaffold(
//       backgroundColor: isDark
//           ? const Color(0xFF0D0D0D)
//           : const Color(0xFFF8F9FA),
//       body: const Center(
//         child: SizedBox(
//           width: 28,
//           height: 28,
//           child: CircularProgressIndicator(
//             color: Color(0xFFE91E8C),
//             strokeWidth: 2.5,
//           ),
//         ),
//       ),
//     );
//   }
// }
// lib/screens/auth_gate.dart
//
// Root navigator for the app.
//
// Routing logic:
//   Firebase null                → LoginPage
//   Firebase user, first load   → SplashScreen
//   Firebase user, no profile   → ProfileSetupScreen  (first-time user)
//   Firebase user, has profile  → App (PersistentBottomNavBar)
//
// AuthGate must NEVER unmount PersistentBottomNavBar on a transient
// AsyncLoading tick — doing so corrupts each tab's NavigatorState and
// triggers '_history.isNotEmpty' crashes on swipe-back devices (Realme, OnePlus).

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../providers/auth_provider.dart';
import '../providers/user_provider.dart';
import '../screens/login_page.dart';
import '../screens/profile_setup_screen.dart';
import '../widgets/nav_bar.dart';
import 'package:cheerchat/providers/auth_provider.dart';
class AuthGate extends ConsumerWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final authState = ref.watch(authStateProvider);

    return authState.when(
      // ── Cold start — Firebase restoring session ────────────────────────
      loading: () => const _SplashScreen(),

      error: (err, _) => Scaffold(
        body: Center(child: Text('Auth error: $err')),
      ),

      data: (fbUser) {
        // ── Not signed in ──────────────────────────────────────────────
        if (fbUser == null) return const LoginPage();

        // ── Signed-in user ─────────────────────────────────────────────
        // ── Show splash during any auth transition ─────────────────────
        //
        // showSplash = true when AsyncLoading AND:
        //   • no previous value at all (first load / fresh rebuild), OR
        //   • previous value was null (just logged out, re-logging in)
        //
        // showSplash = false when AsyncLoading AND:
        //   • previous value was a real AppUser (soft refresh) — NavBar stays
        //
        // This prevents ProfileSetupScreen flashing during logout and
        // during re-login to the same account.
        final showSplash = ref.watch(
          currentUserProvider.select((async) {
            if (async is! AsyncLoading) return false;
            // Soft refresh with a real user cached → don't interrupt NavBar
            if (async.hasValue && async.value != null) return false;
            // First load OR post-logout/pre-login transition → show splash
            return true;
          }),
        );

        if (showSplash) return const _SplashScreen();

        final hasProfile = ref.watch(
          currentUserProvider.select(
            (async) => async.asData?.value != null,
          ),
        );

        return hasProfile
            ? PersistentBottomNavBar(uid: fbUser.uid)
            : const ProfileSetupScreen();
      },
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Splash — shown only during cold-start auth resolution
// ─────────────────────────────────────────────────────────────────────────────

class _SplashScreen extends StatelessWidget {
  const _SplashScreen();

  @override
  Widget build(BuildContext context) {
    final isDark =
        Theme.of(context).brightness == Brightness.dark;
    return Scaffold(
      backgroundColor: isDark
          ? const Color(0xFF0D0D0D)
          : const Color(0xFFF8F9FA),
      body: const Center(
        child: SizedBox(
          width: 28,
          height: 28,
          child: CircularProgressIndicator(
            color: Color(0xFFE91E8C),
            strokeWidth: 2.5,
          ),
        ),
      ),
    );
  }
}