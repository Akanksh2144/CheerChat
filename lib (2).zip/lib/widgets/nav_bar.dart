// lib/widgets/nav_bar.dart
//
// Main app shell with persistent bottom navigation.
//
// Tabs:
//   0  Connect  — HostsGridViewScreen  (browse hosts)
//   1  Random   — RandomCallScreen     (random match)
//   2  Inbox    — InboxScreen          (conversations)
//   3  Profile  — ProfileScreen        (my profile)
//
// ChatScreen is NEVER a tab — it is always pushed via Navigator.push
// from InboxScreen or a HostCard. Mounting it as a tab would subscribe
// its Firestore stream immediately on app start, which causes
// PERMISSION_DENIED for anonymous users and a navigator crash.

import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:persistent_bottom_nav_bar_v2/persistent_bottom_nav_bar_v2.dart';

import 'package:cheerchat/screens/hosts_grid_view.dart';
import 'package:cheerchat/screens/inbox_screen.dart';
import 'package:cheerchat/screens/random_call_screen.dart';
import 'package:cheerchat/screens/profile_screen.dart';
import 'package:cheerchat/theme/app_colors.dart';
import 'package:cheerchat/screens/chat_screen.dart';

class PersistentBottomNavBar extends StatefulWidget {
  const PersistentBottomNavBar({super.key, required this.uid});

  final String uid;

  @override
  State<PersistentBottomNavBar> createState() =>
      _PersistentBottomNavBarState();
}

class _PersistentBottomNavBarState
    extends State<PersistentBottomNavBar> {
  late final PersistentTabController _controller;

  @override
  void initState() {
    super.initState();
    _controller = PersistentTabController(initialIndex: 0);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  List<PersistentTabConfig> _buildTabs() {
    return [
      PersistentTabConfig(
        screen: const HostsGridViewScreen(),
        item: ItemConfig(
          icon: const FaIcon(FontAwesomeIcons.earthAmericas),
          title: 'Connect',
        ),
      ),

      PersistentTabConfig(
        screen: const RandomCallScreen(),
        item: ItemConfig(
          icon: const FaIcon(FontAwesomeIcons.shuffle),
          title: 'Random',
        ),
      ),
      PersistentTabConfig(
        screen: ChatScreen(
          otherUserId: 'haaJCmi8plTE8Wxd1nIpU9uhuuf2',

          otherUserName: 'Pixel XL Pro',
          profileImage: '',
        ),
        item: ItemConfig(
          icon: FaIcon(FontAwesomeIcons.message),
          title: "Random Call",
        ),
      ),
      PersistentTabConfig(
        screen: const InboxScreen(),
        item: ItemConfig(
          icon: const FaIcon(FontAwesomeIcons.solidMessage),
          title: 'Inbox',
        ),
      ),
      PersistentTabConfig(
        screen: const ProfileScreen(),
        item: ItemConfig(
          icon: const FaIcon(FontAwesomeIcons.user),
          title: 'Profile',
        ),
      ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    final c = AppColors.of(context);

    return PopScope(
      // Intercept the Android back gesture / button.
      // PersistentTabView uses its own internal Navigator stack.
      // When the user is already on the root tab, that stack is empty and
      // Flutter throws '_history.isNotEmpty' if the system back is passed
      // through. We handle it here: if a non-root tab is active we switch
      // back to tab 0; if already on tab 0 we do nothing (keeps app alive).
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (_controller.index != 0) {
          _controller.jumpToTab(0);
        }
        // Already on tab 0 — swallow the gesture, don't exit.
      },
      child: PersistentTabView(
        controller: _controller,
        tabs: _buildTabs(),
        gestureNavigationEnabled: false,
        navBarBuilder: (navBarConfig) => NeumorphicBottomNavBar(
          navBarConfig: navBarConfig,
          height: 60,
          navBarDecoration: NavBarDecoration(color: c.surface),
        ),
      ),
    );
  }
}
